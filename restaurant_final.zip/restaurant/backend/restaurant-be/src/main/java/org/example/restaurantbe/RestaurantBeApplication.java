package org.example.restaurantbe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestaurantBeApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestaurantBeApplication.class, args);
	}

}
